# 注意事项：
* 页面的 HTML 代码必须是 `<!DOCTYPE html>` 开头
* 除 IE6、7 外，所有浏览器均支持

# 在线文档
[https://www.layui.com/doc/](https://www.layui.com/doc/)

# 仓库地址
[Github](https://github.com/sentsin/layui/) | [Gitee](https://gitee.com/sentsin/layui) |  [NPM](https://www.npmjs.com/package/layui-src)
